<?php

namespace App\Http\Controllers\Api\Supplier\Profile;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
class ProfileClientController extends Controller
{
    public function storeClient(Request $request){
        $validateData = $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required',
            'phone_number' => 'required',
            'company_name' => 'nullable',
          ]);
          $validateData['password'] = '';
          $validateData['type'] = 2;
          $validateData['master_id'] = Auth::id();
          User::Create($validateData);
        return response()->json(['success'=>true], 200); 
    }
    public function getClients(){
        $clients = User::where('master_id', Auth::id())->get();
        return response()->json(['success'=>true, 'res'=> $clients], 200); 
    }
    public function deleteClient(Request $request){
        $client = User::destroy($request->user_id);
        
        return response()->json(['success'=>true], 200); 
    }
    public function getFavoris(){
        return response()->json(['success'=>true], 200); 
    }
}
