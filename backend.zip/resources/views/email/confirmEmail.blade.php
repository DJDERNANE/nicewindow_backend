<div>

    your Confirmation code is : 
    <h1>
       {{$otp_code}}
    </h1>
</div>