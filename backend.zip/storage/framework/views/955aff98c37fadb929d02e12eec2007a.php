<?php $__env->startSection('content'); ?>
  <h2>التصنيفات الفرعية</h2>
  <div class="row">
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h4 class="fw-bold">إضافة تصنيف فرعي</h4>
          <form action="<?php echo e(route('admin.subcategory.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label class="form-label">التصنيف: </label>
              <select name="category_id" class="form-control form-control-lg border-2" required>
                <option value="">اختر التصنيف</option>
                <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_ar); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (AR): </label>
              <input type="text" name="name_ar" class="form-control border-2 form-control-lg" required />
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (FR): </label>
              <input type="text" name="name_fr" class="form-control border-2 form-control-lg" required />
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (EN): </label>
              <input type="text" name="name_en" class="form-control border-2 form-control-lg" required />
            </div>
            <div class="mb-3">
              <button type="submit" class="btn btn-lg w-100 btn-dark">حفظ</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="col-md-8">
      <div class="card">
        <div class="card-body">
          <h4 class="fw-bold">التصنيفات الفرعية</h4>
          <table class="table-one">
            <thead>
              <tr>
                <th>#</th>
                <th>التصنيف الرئيسي</th>
                <th>الإسم (AR)</th>
                <th>الإسم (EN)</th>
                <th>الإسم (FR)</th>
                <th>خيارات</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr id="tr<?php echo e($subcategory->id); ?>">
                  <td><?php echo e($subcategory->id); ?></td>
                  <td><?php echo e($subcategory->category->name_ar); ?></td>
                  <td><?php echo e($subcategory->name_ar); ?></td>
                  <td><?php echo e($subcategory->name_en); ?></td>
                  <td><?php echo e($subcategory->name_fr); ?></td>
                  <td>
                    <button class="btn btn-xs btn-success" data-bs-target="#editModal" data-bs-toggle="modal" data-subcategory="<?php echo e($subcategory); ?>">
                      <ion-icon name="create-outline"></ion-icon>
                    </button>
                    <button class="btn btn-xs btn-danger" data-bs-target="#deleteModal" data-bs-toggle="modal" onclick="$('#id-for-destroy').val('<?php echo e($subcategory->id); ?>');">
                      <ion-icon name="trash-outline"></ion-icon>
                    </button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="6" align="center">لا توجد بيانات.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- START edit modal -->
  <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content rounded-0">
        <div class="modal-header">
          <h5 class="modal-title">تعديل التصنيف الفرعي</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.subcategory.update')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">التصنيف: </label>
              <select name="category_id" class="form-control form-control-lg border-2" id="e-category_id" required>
                <option value="">اختر التصنيف</option>
                <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_ar); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (AR): </label>
              <input type="text" name="name_ar" class="form-control border-2 form-control-lg" id="e-name_ar" />
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (FR): </label>
              <input type="text" name="name_fr" class="form-control border-2 form-control-lg" id="e-name_fr" />
            </div>
            <div class="mb-3">
              <label class="form-label">الإسم (EN): </label>
              <input type="text" name="name_en" class="form-control border-2 form-control-lg" id="e-name_en" />
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="id" value="" id="e-id" />
            <button type="submit" class="btn btn-dark w-100 btn-lg" data-bs-dismiss="modal">حفظ</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- END edit modal -->

  <!-- START delete modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content rounded-0">
        <div class="modal-header">
          <h5 class="modal-title">هل حقا تريد حذف التصنيف الفرعي؟</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-footer">
          <input type="hidden" name="id" value="" id="id-for-destroy" />
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">غلق</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal" onclick="destroySubcategory();">حذف</button>
        </div>
      </div>
    </div>
  </div>
  <!-- END delete modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    function destroySubcategory() {
      let id = $('#id-for-destroy').val();
      $.post('<?php echo e(route('admin.subcategory.destroy')); ?>', {id:id, _token:'<?php echo e(csrf_token()); ?>'}, function(res) {
        $('#tr'+id).remove();
      }, 'json');
    }

    $('#editModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var subcategory = button.data('subcategory');
      
      var modal = $(this);
      modal.find('#e-category_id').val(subcategory.category_id);
      modal.find('#e-name_ar').val(subcategory.name_ar);
      modal.find('#e-name_en').val(subcategory.name_en);
      modal.find('#e-name_fr').val(subcategory.name_fr);
      modal.find('#e-id').val(subcategory.id);
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NW_API\resources\views/admin/subcategories.blade.php ENDPATH**/ ?>