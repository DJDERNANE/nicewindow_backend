<div>

    your Confirmation code is : 
    <h1>
       <?php echo e($otp_code); ?>

    </h1>
</div><?php /**PATH C:\xampp\htdocs\NW_API\resources\views/email/confirmEmail.blade.php ENDPATH**/ ?>