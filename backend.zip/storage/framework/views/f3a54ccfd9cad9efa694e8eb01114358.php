<?php $__env->startSection('content'); ?>
  <h2>طلبات من الناقلين</h2>
  <div class="card">
    <div class="card-body">
      <table class="table-one">
        <thead>
          <tr>
            <th>#</th>
            <th>النجار</th>
            <th>الناقل</th>
            <th>العنوان</th>
            <th>السعر</th>
            <th>الحالة</th>
            <th>التاريخ</th>
            <th>خيارات</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($order->id); ?></td>
              <td class="<?php echo e($order->carpentry->deleted_at ? 'text-danger' : ''); ?>"><?php echo e($order->carpentry->firstname.' '.$order->carpentry->lastname); ?></td>
              <td class="<?php echo e($order->supplier->deleted_at ? 'text-danger' : ''); ?>"><?php echo e($order->supplier->firstname.' '.$order->supplier->lastname); ?></td>
              <td><?php echo e($order->shipping_address); ?></td>
              <td><?php echo e($order->total_price); ?> د.ج</td>
              <td>
                <?php if($order->status === 1): ?>
                  <span class="text-warning">قيد التوصيل</span>
                <?php elseif($order->status === 2): ?>
                  <span class="text-success">منتهية</span>
                <?php elseif($order->status === 3): ?>
                  <span class="text-danger">ملغية</span>
                <?php else: ?>
                  <span class="text-primary">قيد الإنتظار</span>
                <?php endif; ?>
              </td>
              <td><?php echo e($order->created_at); ?></td>
              <td>
                <a href="<?php echo e(route('admin.order.profile', ['order' => $order->id])); ?>">
                  <button class="btn btn-success btn-xs">
                    <ion-icon name="document-outline"></ion-icon>
                  </button>
                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <?php if($orders && count($orders) > 0): ?>
      <div class="card-footer">
        <nav aria-label="Page navigation example">
          <ul class="pagination">
            <?= $orders->previousPageUrl() ? '<li class="page-item"><a class="page-link" href="'.$orders->previousPageUrl().'"> '.($orders->currentPage()-1).' </a></li>' : '' ?>
            <li class="page-item disabled"><a class="page-link" href="<?php echo e($orders->url($orders->currentPage())); ?>"> <?php echo e($orders->currentPage()); ?> </a></li>
            <?= $orders->nextPageUrl() ? '<li class="page-item"><a class="page-link" href="'.$orders->nextPageUrl().'"> '.($orders->currentPage()+1).' </a></li>' : '' ?>
          </ul>
        </nav>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NW_API\resources\views/admin/profile_orders.blade.php ENDPATH**/ ?>