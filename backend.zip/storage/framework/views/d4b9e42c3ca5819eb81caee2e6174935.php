<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <?php echo $__env->make('layouts.home.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <div class="hero_area">
      <?php echo $__env->make('layouts.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->yieldContent('content'); ?>

      <?php echo $__env->make('layouts.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\NW_API\resources\views/layouts/home/app.blade.php ENDPATH**/ ?>