<?php $__env->startSection('content'); ?>
  <h2>المستخدمين</h2>
  <div class="card">
    <div class="card-body">
      <table class="table-one">
        <thead>
          <tr>
            <th>#</th>
            <th>الإسم الكامل</th>
            <th>البريد الإلكتروني</th>
            <th>رقم الهاتف</th>
            <th>إعدادات</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($user->id); ?></td>
              <td><?php echo e($user->firstname.' '.$user->lastname); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td><?php echo e($user->phone_number); ?></td>
              <td>
                <a href="<?php echo e(route('admin.user', ['user' => $user->id])); ?>">
                  <button class="btn btn-success btn-xs">
                    <ion-icon name="person-outline"></ion-icon>
                  </button>
                </a>
                <button class="btn btn-danger btn-xs">
                  <ion-icon name="trash-outline"></ion-icon>
                </button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="5" align="center">لا توجد بيانات</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if($users && count($users) > 0): ?>
      <div class="card-footer">
        <nav aria-label="Page navigation example">
          <ul class="pagination">
            <?= $users->previousPageUrl() ? '<li class="page-item"><a class="page-link" href="'.$users->previousPageUrl().'"> '.($users->currentPage()-1).' </a></li>' : '' ?>
            <li class="page-item disabled"><a class="page-link" href="<?php echo e($users->url($users->currentPage())); ?>"> <?php echo e($users->currentPage()); ?> </a></li>
            <?= $users->nextPageUrl() ? '<li class="page-item"><a class="page-link" href="'.$users->nextPageUrl().'"> '.($users->currentPage()+1).' </a></li>' : '' ?>
          </ul>
        </nav>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NW_API\resources\views/admin/users.blade.php ENDPATH**/ ?>