<?php

namespace App\Common;

final class ProfileOrderStatus {
  const WITING = 0;
  const PROGRESS = 1;
  const FINISHED = 2;
  const CANCELED = 3;
}