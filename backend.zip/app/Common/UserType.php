<?php

namespace App\Common;

final class UserType {
  const ADMIN = 0;
  const CLIENT = 1;
  const CARPENTRY = 2;
  const SUPPLIER_PROFILE = 3;
}