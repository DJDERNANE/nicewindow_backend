<?php

namespace App\Common;

final class ProfileOrderPaymentStatus {
  const WITING = 0;
  const FINISHED = 1;
}